<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap/css/bootstrap.min.css')); ?>">
    <title>Dashboard</title>
</head>
<body>
    <div class="conteiner">
        <div class="row">
            <div class="col-md-6 col-md-offset-3">
                <h4>Dashboard</h4><hr>
                <table class="table table-hover">
                    <thead>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Password</th>
                    </thead>
                    <tbody>
                        <tr>
                            <td><?php echo e($LoggedUserInfo['name']); ?></td>
                            <td><?php echo e($LoggedUserInfo['email']); ?></td>
                            <button type="button" id="icon-mostar-senha" class="btn btn-default btn-xs fas fa-eye-slash"><td>**********</td></button>
                            <td><a href="<?php echo e(Route('auth.logout')); ?>">Logout</a></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
</body>
</html><?php /**PATH C:\laravel\project01\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>